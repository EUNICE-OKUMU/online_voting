    </div> <!-- End of container from header -->
    <!-- Footer -->
    <footer class="py-3 my-4">
        <p class="text-center text-muted">© <?php echo date('Y'); ?> Zetech University Online Voting System. All rights reserved.</p>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 